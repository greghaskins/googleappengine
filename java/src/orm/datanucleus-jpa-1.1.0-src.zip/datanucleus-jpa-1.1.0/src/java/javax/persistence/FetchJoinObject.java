package javax.persistence;

/**
 * Interface used for the result of a fetch join.
 */
public interface FetchJoinObject
{

}