package javax.persistence;

public interface Subquery extends PredicateOperand
{

}
