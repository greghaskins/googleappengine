/**********************************************************************
Copyright (c) 2008 Andy Jefferson and others. All rights reserved.
Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

    http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.

Contributors:
    ...
**********************************************************************/
package org.datanucleus.jpa.criteria;

import java.util.Calendar;
import java.util.Date;
import java.util.List;

import javax.persistence.CaseExpression;
import javax.persistence.DomainObject;
import javax.persistence.Expression;
import javax.persistence.OrderByItem;
import javax.persistence.PathExpression;
import javax.persistence.Predicate;
import javax.persistence.PredicateOperand;
import javax.persistence.QueryDefinition;
import javax.persistence.SelectItem;
import javax.persistence.Subquery;

/**
 * Implementation of a JPA2 query definition.
 */
public class QueryDefinitionImpl implements QueryDefinition
{
    /* (non-Javadoc)
     * @see javax.persistence.QueryDefinition#addRoot(java.lang.Class)
     */
    public DomainObject addRoot(Class cls)
    {
        // TODO Auto-generated method stub
        return null;
    }

    /* (non-Javadoc)
     * @see javax.persistence.QueryDefinition#addSubqueryRoot(javax.persistence.PathExpression)
     */
    public DomainObject addSubqueryRoot(PathExpression path)
    {
        // TODO Auto-generated method stub
        return null;
    }

    /* (non-Javadoc)
     * @see javax.persistence.QueryDefinition#all()
     */
    public Subquery all()
    {
        // TODO Auto-generated method stub
        return null;
    }

    /* (non-Javadoc)
     * @see javax.persistence.QueryDefinition#any()
     */
    public Subquery any()
    {
        // TODO Auto-generated method stub
        return null;
    }

    /* (non-Javadoc)
     * @see javax.persistence.QueryDefinition#coalesce(javax.persistence.Expression[])
     */
    public Expression coalesce(Expression... exp)
    {
        // TODO Auto-generated method stub
        return null;
    }

    /* (non-Javadoc)
     * @see javax.persistence.QueryDefinition#coalesce(java.lang.String[])
     */
    public Expression coalesce(String... exp)
    {
        // TODO Auto-generated method stub
        return null;
    }

    /* (non-Javadoc)
     * @see javax.persistence.QueryDefinition#coalesce(java.util.Date[])
     */
    public Expression coalesce(Date... exp)
    {
        // TODO Auto-generated method stub
        return null;
    }

    /* (non-Javadoc)
     * @see javax.persistence.QueryDefinition#coalesce(java.util.Calendar[])
     */
    public Expression coalesce(Calendar... exp)
    {
        // TODO Auto-generated method stub
        return null;
    }

    /* (non-Javadoc)
     * @see javax.persistence.QueryDefinition#currentDate()
     */
    public Expression currentDate()
    {
        // TODO Auto-generated method stub
        return null;
    }

    /* (non-Javadoc)
     * @see javax.persistence.QueryDefinition#currentTime()
     */
    public Expression currentTime()
    {
        // TODO Auto-generated method stub
        return null;
    }

    /* (non-Javadoc)
     * @see javax.persistence.QueryDefinition#currentTimestamp()
     */
    public Expression currentTimestamp()
    {
        // TODO Auto-generated method stub
        return null;
    }

    /* (non-Javadoc)
     * @see javax.persistence.QueryDefinition#exists()
     */
    public Predicate exists()
    {
        // TODO Auto-generated method stub
        return null;
    }

    /* (non-Javadoc)
     * @see javax.persistence.QueryDefinition#generalCase()
     */
    public CaseExpression generalCase()
    {
        // TODO Auto-generated method stub
        return null;
    }

    /* (non-Javadoc)
     * @see javax.persistence.QueryDefinition#groupBy(javax.persistence.PathExpression[])
     */
    public QueryDefinition groupBy(PathExpression... pathExprs)
    {
        // TODO Auto-generated method stub
        return null;
    }

    /* (non-Javadoc)
     * @see javax.persistence.QueryDefinition#groupBy(java.util.List)
     */
    public QueryDefinition groupBy(List<PathExpression> pathExprList)
    {
        // TODO Auto-generated method stub
        return null;
    }

    /* (non-Javadoc)
     * @see javax.persistence.QueryDefinition#having(javax.persistence.Predicate)
     */
    public QueryDefinition having(Predicate predicate)
    {
        // TODO Auto-generated method stub
        return null;
    }

    /* (non-Javadoc)
     * @see javax.persistence.QueryDefinition#literal(java.lang.String)
     */
    public Expression literal(String s)
    {
        // TODO Auto-generated method stub
        return null;
    }

    /* (non-Javadoc)
     * @see javax.persistence.QueryDefinition#literal(java.lang.Number)
     */
    public Expression literal(Number n)
    {
        // TODO Auto-generated method stub
        return null;
    }

    /* (non-Javadoc)
     * @see javax.persistence.QueryDefinition#literal(boolean)
     */
    public Expression literal(boolean b)
    {
        // TODO Auto-generated method stub
        return null;
    }

    /* (non-Javadoc)
     * @see javax.persistence.QueryDefinition#literal(java.util.Calendar)
     */
    public Expression literal(Calendar c)
    {
        // TODO Auto-generated method stub
        return null;
    }

    /* (non-Javadoc)
     * @see javax.persistence.QueryDefinition#literal(java.util.Date)
     */
    public Expression literal(Date d)
    {
        // TODO Auto-generated method stub
        return null;
    }

    /* (non-Javadoc)
     * @see javax.persistence.QueryDefinition#literal(char)
     */
    public Expression literal(char c)
    {
        // TODO Auto-generated method stub
        return null;
    }

    /* (non-Javadoc)
     * @see javax.persistence.QueryDefinition#literal(java.lang.Class)
     */
    public Expression literal(Class cls)
    {
        // TODO Auto-generated method stub
        return null;
    }

    /* (non-Javadoc)
     * @see javax.persistence.QueryDefinition#literal(java.lang.Enum)
     */
    public Expression literal(Enum<?> e)
    {
        // TODO Auto-generated method stub
        return null;
    }

    /* (non-Javadoc)
     * @see javax.persistence.QueryDefinition#newInstance(java.lang.Class, javax.persistence.SelectItem[])
     */
    public SelectItem newInstance(Class cls, SelectItem... args)
    {
        // TODO Auto-generated method stub
        return null;
    }

    /* (non-Javadoc)
     * @see javax.persistence.QueryDefinition#nullLiteral()
     */
    public Expression nullLiteral()
    {
        // TODO Auto-generated method stub
        return null;
    }

    /* (non-Javadoc)
     * @see javax.persistence.QueryDefinition#nullif(javax.persistence.Expression, javax.persistence.Expression)
     */
    public Expression nullif(Expression exp1, Expression exp2)
    {
        // TODO Auto-generated method stub
        return null;
    }

    /* (non-Javadoc)
     * @see javax.persistence.QueryDefinition#nullif(java.lang.Number, java.lang.Number)
     */
    public Expression nullif(Number arg1, Number arg2)
    {
        // TODO Auto-generated method stub
        return null;
    }

    /* (non-Javadoc)
     * @see javax.persistence.QueryDefinition#nullif(java.lang.String, java.lang.String)
     */
    public Expression nullif(String arg1, String arg2)
    {
        // TODO Auto-generated method stub
        return null;
    }

    /* (non-Javadoc)
     * @see javax.persistence.QueryDefinition#nullif(java.util.Date, java.util.Date)
     */
    public Expression nullif(Date arg1, Date arg2)
    {
        // TODO Auto-generated method stub
        return null;
    }

    /* (non-Javadoc)
     * @see javax.persistence.QueryDefinition#nullif(java.util.Calendar, java.util.Calendar)
     */
    public Expression nullif(Calendar arg1, Calendar arg2)
    {
        // TODO Auto-generated method stub
        return null;
    }

    /* (non-Javadoc)
     * @see javax.persistence.QueryDefinition#nullif(java.lang.Class, java.lang.Class)
     */
    public Expression nullif(Class arg1, Class arg2)
    {
        // TODO Auto-generated method stub
        return null;
    }

    /* (non-Javadoc)
     * @see javax.persistence.QueryDefinition#nullif(java.lang.Enum, java.lang.Enum)
     */
    public Expression nullif(Enum<?> arg1, Enum<?> arg2)
    {
        // TODO Auto-generated method stub
        return null;
    }

    /* (non-Javadoc)
     * @see javax.persistence.QueryDefinition#orderBy(javax.persistence.OrderByItem[])
     */
    public QueryDefinition orderBy(OrderByItem... orderByItems)
    {
        // TODO Auto-generated method stub
        return null;
    }

    /* (non-Javadoc)
     * @see javax.persistence.QueryDefinition#orderBy(java.util.List)
     */
    public QueryDefinition orderBy(List<OrderByItem> orderByItemList)
    {
        // TODO Auto-generated method stub
        return null;
    }

    /* (non-Javadoc)
     * @see javax.persistence.QueryDefinition#param(java.lang.String)
     */
    public Expression param(String name)
    {
        // TODO Auto-generated method stub
        return null;
    }

    /* (non-Javadoc)
     * @see javax.persistence.QueryDefinition#predicate(boolean)
     */
    public Predicate predicate(boolean b)
    {
        // TODO Auto-generated method stub
        return null;
    }

    /* (non-Javadoc)
     * @see javax.persistence.QueryDefinition#select(javax.persistence.SelectItem[])
     */
    public QueryDefinition select(SelectItem... selectItems)
    {
        // TODO Auto-generated method stub
        return null;
    }

    /* (non-Javadoc)
     * @see javax.persistence.QueryDefinition#select(java.util.List)
     */
    public QueryDefinition select(List<SelectItem> selectItemList)
    {
        // TODO Auto-generated method stub
        return null;
    }

    /* (non-Javadoc)
     * @see javax.persistence.QueryDefinition#selectDistinct(javax.persistence.SelectItem[])
     */
    public QueryDefinition selectDistinct(SelectItem... selectItems)
    {
        // TODO Auto-generated method stub
        return null;
    }

    /* (non-Javadoc)
     * @see javax.persistence.QueryDefinition#selectDistinct(java.util.List)
     */
    public QueryDefinition selectDistinct(List<SelectItem> selectItemList)
    {
        // TODO Auto-generated method stub
        return null;
    }

    /* (non-Javadoc)
     * @see javax.persistence.QueryDefinition#simpleCase(javax.persistence.Expression)
     */
    public CaseExpression simpleCase(Expression caseOperand)
    {
        // TODO Auto-generated method stub
        return null;
    }

    /* (non-Javadoc)
     * @see javax.persistence.QueryDefinition#simpleCase(java.lang.Number)
     */
    public CaseExpression simpleCase(Number caseOperand)
    {
        // TODO Auto-generated method stub
        return null;
    }

    /* (non-Javadoc)
     * @see javax.persistence.QueryDefinition#simpleCase(java.lang.String)
     */
    public CaseExpression simpleCase(String caseOperand)
    {
        // TODO Auto-generated method stub
        return null;
    }

    /* (non-Javadoc)
     * @see javax.persistence.QueryDefinition#simpleCase(java.util.Date)
     */
    public CaseExpression simpleCase(Date caseOperand)
    {
        // TODO Auto-generated method stub
        return null;
    }

    /* (non-Javadoc)
     * @see javax.persistence.QueryDefinition#simpleCase(java.util.Calendar)
     */
    public CaseExpression simpleCase(Calendar caseOperand)
    {
        // TODO Auto-generated method stub
        return null;
    }

    /* (non-Javadoc)
     * @see javax.persistence.QueryDefinition#simpleCase(java.lang.Class)
     */
    public CaseExpression simpleCase(Class caseOperand)
    {
        // TODO Auto-generated method stub
        return null;
    }

    /* (non-Javadoc)
     * @see javax.persistence.QueryDefinition#simpleCase(java.lang.Enum)
     */
    public CaseExpression simpleCase(Enum<?> caseOperand)
    {
        // TODO Auto-generated method stub
        return null;
    }

    /* (non-Javadoc)
     * @see javax.persistence.QueryDefinition#some()
     */
    public Subquery some()
    {
        // TODO Auto-generated method stub
        return null;
    }

    /* (non-Javadoc)
     * @see javax.persistence.QueryDefinition#where(javax.persistence.Predicate)
     */
    public QueryDefinition where(Predicate predicate)
    {
        // TODO Auto-generated method stub
        return null;
    }

    /* (non-Javadoc)
     * @see javax.persistence.PredicateOperand#between(javax.persistence.PredicateOperand, javax.persistence.PredicateOperand)
     */
    public Predicate between(PredicateOperand arg1, PredicateOperand arg2)
    {
        // TODO Auto-generated method stub
        return null;
    }

    /* (non-Javadoc)
     * @see javax.persistence.PredicateOperand#between(javax.persistence.PredicateOperand, java.lang.Number)
     */
    public Predicate between(PredicateOperand arg1, Number arg2)
    {
        // TODO Auto-generated method stub
        return null;
    }

    /* (non-Javadoc)
     * @see javax.persistence.PredicateOperand#between(java.lang.Number, javax.persistence.PredicateOperand)
     */
    public Predicate between(Number arg1, PredicateOperand arg2)
    {
        // TODO Auto-generated method stub
        return null;
    }

    /* (non-Javadoc)
     * @see javax.persistence.PredicateOperand#between(java.lang.Number, java.lang.Number)
     */
    public Predicate between(Number arg1, Number arg2)
    {
        // TODO Auto-generated method stub
        return null;
    }

    /* (non-Javadoc)
     * @see javax.persistence.PredicateOperand#between(javax.persistence.PredicateOperand, java.lang.String)
     */
    public Predicate between(PredicateOperand arg1, String arg2)
    {
        // TODO Auto-generated method stub
        return null;
    }

    /* (non-Javadoc)
     * @see javax.persistence.PredicateOperand#between(java.lang.String, javax.persistence.PredicateOperand)
     */
    public Predicate between(String arg1, PredicateOperand arg2)
    {
        // TODO Auto-generated method stub
        return null;
    }

    /* (non-Javadoc)
     * @see javax.persistence.PredicateOperand#between(java.lang.String, java.lang.String)
     */
    public Predicate between(String arg1, String arg2)
    {
        // TODO Auto-generated method stub
        return null;
    }

    /* (non-Javadoc)
     * @see javax.persistence.PredicateOperand#between(javax.persistence.PredicateOperand, java.util.Date)
     */
    public Predicate between(PredicateOperand arg1, Date arg2)
    {
        // TODO Auto-generated method stub
        return null;
    }

    /* (non-Javadoc)
     * @see javax.persistence.PredicateOperand#between(java.util.Date, javax.persistence.PredicateOperand)
     */
    public Predicate between(Date arg1, PredicateOperand arg2)
    {
        // TODO Auto-generated method stub
        return null;
    }

    /* (non-Javadoc)
     * @see javax.persistence.PredicateOperand#between(java.util.Date, java.util.Date)
     */
    public Predicate between(Date arg1, Date arg2)
    {
        // TODO Auto-generated method stub
        return null;
    }

    /* (non-Javadoc)
     * @see javax.persistence.PredicateOperand#between(javax.persistence.PredicateOperand, java.util.Calendar)
     */
    public Predicate between(PredicateOperand arg1, Calendar arg2)
    {
        // TODO Auto-generated method stub
        return null;
    }

    /* (non-Javadoc)
     * @see javax.persistence.PredicateOperand#between(java.util.Calendar, javax.persistence.PredicateOperand)
     */
    public Predicate between(Calendar arg1, PredicateOperand arg2)
    {
        // TODO Auto-generated method stub
        return null;
    }

    /* (non-Javadoc)
     * @see javax.persistence.PredicateOperand#between(java.util.Calendar, java.util.Calendar)
     */
    public Predicate between(Calendar arg1, Calendar arg2)
    {
        // TODO Auto-generated method stub
        return null;
    }

    /* (non-Javadoc)
     * @see javax.persistence.PredicateOperand#equal(javax.persistence.PredicateOperand)
     */
    public Predicate equal(PredicateOperand arg)
    {
        // TODO Auto-generated method stub
        return null;
    }

    /* (non-Javadoc)
     * @see javax.persistence.PredicateOperand#equal(java.lang.Class)
     */
    public Predicate equal(Class cls)
    {
        // TODO Auto-generated method stub
        return null;
    }

    /* (non-Javadoc)
     * @see javax.persistence.PredicateOperand#equal(java.lang.Number)
     */
    public Predicate equal(Number arg)
    {
        // TODO Auto-generated method stub
        return null;
    }

    /* (non-Javadoc)
     * @see javax.persistence.PredicateOperand#equal(java.lang.String)
     */
    public Predicate equal(String arg)
    {
        // TODO Auto-generated method stub
        return null;
    }

    /* (non-Javadoc)
     * @see javax.persistence.PredicateOperand#equal(boolean)
     */
    public Predicate equal(boolean arg)
    {
        // TODO Auto-generated method stub
        return null;
    }

    /* (non-Javadoc)
     * @see javax.persistence.PredicateOperand#equal(java.util.Date)
     */
    public Predicate equal(Date arg)
    {
        // TODO Auto-generated method stub
        return null;
    }

    /* (non-Javadoc)
     * @see javax.persistence.PredicateOperand#equal(java.util.Calendar)
     */
    public Predicate equal(Calendar arg)
    {
        // TODO Auto-generated method stub
        return null;
    }

    /* (non-Javadoc)
     * @see javax.persistence.PredicateOperand#equal(java.lang.Enum)
     */
    public Predicate equal(Enum<?> e)
    {
        // TODO Auto-generated method stub
        return null;
    }

    /* (non-Javadoc)
     * @see javax.persistence.PredicateOperand#greaterEqual(javax.persistence.PredicateOperand)
     */
    public Predicate greaterEqual(PredicateOperand arg)
    {
        // TODO Auto-generated method stub
        return null;
    }

    /* (non-Javadoc)
     * @see javax.persistence.PredicateOperand#greaterEqual(java.lang.Number)
     */
    public Predicate greaterEqual(Number arg)
    {
        // TODO Auto-generated method stub
        return null;
    }

    /* (non-Javadoc)
     * @see javax.persistence.PredicateOperand#greaterEqual(java.lang.String)
     */
    public Predicate greaterEqual(String arg)
    {
        // TODO Auto-generated method stub
        return null;
    }

    /* (non-Javadoc)
     * @see javax.persistence.PredicateOperand#greaterEqual(java.util.Date)
     */
    public Predicate greaterEqual(Date arg)
    {
        // TODO Auto-generated method stub
        return null;
    }

    /* (non-Javadoc)
     * @see javax.persistence.PredicateOperand#greaterEqual(java.util.Calendar)
     */
    public Predicate greaterEqual(Calendar arg)
    {
        // TODO Auto-generated method stub
        return null;
    }

    /* (non-Javadoc)
     * @see javax.persistence.PredicateOperand#greaterThan(javax.persistence.PredicateOperand)
     */
    public Predicate greaterThan(PredicateOperand arg)
    {
        // TODO Auto-generated method stub
        return null;
    }

    /* (non-Javadoc)
     * @see javax.persistence.PredicateOperand#greaterThan(java.lang.Number)
     */
    public Predicate greaterThan(Number arg)
    {
        // TODO Auto-generated method stub
        return null;
    }

    /* (non-Javadoc)
     * @see javax.persistence.PredicateOperand#greaterThan(java.lang.String)
     */
    public Predicate greaterThan(String arg)
    {
        // TODO Auto-generated method stub
        return null;
    }

    /* (non-Javadoc)
     * @see javax.persistence.PredicateOperand#greaterThan(java.util.Date)
     */
    public Predicate greaterThan(Date arg)
    {
        // TODO Auto-generated method stub
        return null;
    }

    /* (non-Javadoc)
     * @see javax.persistence.PredicateOperand#greaterThan(java.util.Calendar)
     */
    public Predicate greaterThan(Calendar arg)
    {
        // TODO Auto-generated method stub
        return null;
    }

    /* (non-Javadoc)
     * @see javax.persistence.PredicateOperand#lessEqual(javax.persistence.PredicateOperand)
     */
    public Predicate lessEqual(PredicateOperand arg)
    {
        // TODO Auto-generated method stub
        return null;
    }

    /* (non-Javadoc)
     * @see javax.persistence.PredicateOperand#lessEqual(java.lang.Number)
     */
    public Predicate lessEqual(Number arg)
    {
        // TODO Auto-generated method stub
        return null;
    }

    /* (non-Javadoc)
     * @see javax.persistence.PredicateOperand#lessEqual(java.lang.String)
     */
    public Predicate lessEqual(String arg)
    {
        // TODO Auto-generated method stub
        return null;
    }

    /* (non-Javadoc)
     * @see javax.persistence.PredicateOperand#lessEqual(java.util.Date)
     */
    public Predicate lessEqual(Date arg)
    {
        // TODO Auto-generated method stub
        return null;
    }

    /* (non-Javadoc)
     * @see javax.persistence.PredicateOperand#lessEqual(java.util.Calendar)
     */
    public Predicate lessEqual(Calendar arg)
    {
        // TODO Auto-generated method stub
        return null;
    }

    /* (non-Javadoc)
     * @see javax.persistence.PredicateOperand#lessThan(javax.persistence.PredicateOperand)
     */
    public Predicate lessThan(PredicateOperand arg)
    {
        // TODO Auto-generated method stub
        return null;
    }

    /* (non-Javadoc)
     * @see javax.persistence.PredicateOperand#lessThan(java.lang.Number)
     */
    public Predicate lessThan(Number arg)
    {
        // TODO Auto-generated method stub
        return null;
    }

    /* (non-Javadoc)
     * @see javax.persistence.PredicateOperand#lessThan(java.lang.String)
     */
    public Predicate lessThan(String arg)
    {
        // TODO Auto-generated method stub
        return null;
    }

    /* (non-Javadoc)
     * @see javax.persistence.PredicateOperand#lessThan(java.util.Date)
     */
    public Predicate lessThan(Date arg)
    {
        // TODO Auto-generated method stub
        return null;
    }

    /* (non-Javadoc)
     * @see javax.persistence.PredicateOperand#lessThan(java.util.Calendar)
     */
    public Predicate lessThan(Calendar arg)
    {
        // TODO Auto-generated method stub
        return null;
    }

    /* (non-Javadoc)
     * @see javax.persistence.PredicateOperand#like(javax.persistence.PredicateOperand)
     */
    public Predicate like(PredicateOperand pattern)
    {
        // TODO Auto-generated method stub
        return null;
    }

    /* (non-Javadoc)
     * @see javax.persistence.PredicateOperand#like(javax.persistence.PredicateOperand, javax.persistence.PredicateOperand)
     */
    public Predicate like(PredicateOperand pattern, PredicateOperand escapeChar)
    {
        // TODO Auto-generated method stub
        return null;
    }

    /* (non-Javadoc)
     * @see javax.persistence.PredicateOperand#like(javax.persistence.PredicateOperand, char)
     */
    public Predicate like(PredicateOperand pattern, char escapeChar)
    {
        // TODO Auto-generated method stub
        return null;
    }

    /* (non-Javadoc)
     * @see javax.persistence.PredicateOperand#like(java.lang.String)
     */
    public Predicate like(String pattern)
    {
        // TODO Auto-generated method stub
        return null;
    }

    /* (non-Javadoc)
     * @see javax.persistence.PredicateOperand#like(java.lang.String, javax.persistence.PredicateOperand)
     */
    public Predicate like(String pattern, PredicateOperand escapeChar)
    {
        // TODO Auto-generated method stub
        return null;
    }

    /* (non-Javadoc)
     * @see javax.persistence.PredicateOperand#like(java.lang.String, char)
     */
    public Predicate like(String pattern, char escapeChar)
    {
        // TODO Auto-generated method stub
        return null;
    }

    /* (non-Javadoc)
     * @see javax.persistence.PredicateOperand#notEqual(javax.persistence.PredicateOperand)
     */
    public Predicate notEqual(PredicateOperand arg)
    {
        // TODO Auto-generated method stub
        return null;
    }

    /* (non-Javadoc)
     * @see javax.persistence.PredicateOperand#notEqual(java.lang.Class)
     */
    public Predicate notEqual(Class cls)
    {
        // TODO Auto-generated method stub
        return null;
    }

    /* (non-Javadoc)
     * @see javax.persistence.PredicateOperand#notEqual(java.lang.Number)
     */
    public Predicate notEqual(Number arg)
    {
        // TODO Auto-generated method stub
        return null;
    }

    /* (non-Javadoc)
     * @see javax.persistence.PredicateOperand#notEqual(java.lang.String)
     */
    public Predicate notEqual(String arg)
    {
        // TODO Auto-generated method stub
        return null;
    }

    /* (non-Javadoc)
     * @see javax.persistence.PredicateOperand#notEqual(boolean)
     */
    public Predicate notEqual(boolean arg)
    {
        // TODO Auto-generated method stub
        return null;
    }

    /* (non-Javadoc)
     * @see javax.persistence.PredicateOperand#notEqual(java.util.Date)
     */
    public Predicate notEqual(Date arg)
    {
        // TODO Auto-generated method stub
        return null;
    }

    /* (non-Javadoc)
     * @see javax.persistence.PredicateOperand#notEqual(java.util.Calendar)
     */
    public Predicate notEqual(Calendar arg)
    {
        // TODO Auto-generated method stub
        return null;
    }

    /* (non-Javadoc)
     * @see javax.persistence.PredicateOperand#notEqual(java.lang.Enum)
     */
    public Predicate notEqual(Enum<?> e)
    {
        // TODO Auto-generated method stub
        return null;
    }
}