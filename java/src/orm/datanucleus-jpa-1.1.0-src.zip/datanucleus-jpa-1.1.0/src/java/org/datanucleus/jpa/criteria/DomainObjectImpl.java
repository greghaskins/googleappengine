/**********************************************************************
Copyright (c) 2009 Andy Jefferson and others. All rights reserved.
Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

    http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.

Contributors:
    ...
**********************************************************************/
package org.datanucleus.jpa.criteria;

import javax.persistence.DomainObject;
import javax.persistence.Expression;
import javax.persistence.FetchJoinObject;
import javax.persistence.PathExpression;
import javax.persistence.SelectItem;

/**
 * Implementation of a JPA DomainObject.
 */
public class DomainObjectImpl implements DomainObject
{

    /* (non-Javadoc)
     * @see javax.persistence.DomainObject#entry()
     */
    public SelectItem entry()
    {
        // TODO Auto-generated method stub
        return null;
    }

    /* (non-Javadoc)
     * @see javax.persistence.DomainObject#index()
     */
    public Expression index()
    {
        // TODO Auto-generated method stub
        return null;
    }

    /* (non-Javadoc)
     * @see javax.persistence.DomainObject#join(java.lang.String)
     */
    public DomainObject join(String attribute)
    {
        // TODO Auto-generated method stub
        return null;
    }

    /* (non-Javadoc)
     * @see javax.persistence.DomainObject#joinFetch(java.lang.String)
     */
    public FetchJoinObject joinFetch(String attribute)
    {
        // TODO Auto-generated method stub
        return null;
    }

    /* (non-Javadoc)
     * @see javax.persistence.DomainObject#key()
     */
    public PathExpression key()
    {
        // TODO Auto-generated method stub
        return null;
    }

    /* (non-Javadoc)
     * @see javax.persistence.DomainObject#leftJoin(java.lang.String)
     */
    public DomainObject leftJoin(String attribute)
    {
        // TODO Auto-generated method stub
        return null;
    }

    /* (non-Javadoc)
     * @see javax.persistence.DomainObject#leftJoinFetch(java.lang.String)
     */
    public FetchJoinObject leftJoinFetch(String attribute)
    {
        // TODO Auto-generated method stub
        return null;
    }

    /* (non-Javadoc)
     * @see javax.persistence.DomainObject#value()
     */
    public PathExpression value()
    {
        // TODO Auto-generated method stub
        return null;
    }
}