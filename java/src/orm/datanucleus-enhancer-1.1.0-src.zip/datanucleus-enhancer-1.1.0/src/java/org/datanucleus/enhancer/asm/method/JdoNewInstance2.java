/**********************************************************************
Copyright (c) 2007 Andy Jefferson and others. All rights reserved.
Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

    http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.

Contributors:
    ...
**********************************************************************/
package org.datanucleus.enhancer.asm.method;

import javax.jdo.spi.PersistenceCapable;
import javax.jdo.spi.StateManager;

import org.datanucleus.enhancer.ClassEnhancer;
import org.datanucleus.enhancer.asm.ASMClassMethod;
import org.datanucleus.enhancer.asm.ASMUtils;
import org.objectweb.asm.Label;
import org.objectweb.asm.Opcodes;

/**
 * Method to generate the method "jdoNewInstance" using ASM.
 * <pre>
 * public PersistenceCapable jdoNewInstance(StateManager sm, Object o)
 * {
 *     Answer result = new Answer();
 *     result.jdoFlags = (byte) 1;
 *     result.jdoStateManager = sm;
 *     result.jdoCopyKeyFieldsFromObjectId(o);
 *     return result;
 * }
 * </pre>
 * and throw an exception when the class is abstract
 * @version $Revision: 1.7 $
 */
public class JdoNewInstance2 extends ASMClassMethod
{
    public static JdoNewInstance2 getInstance(ClassEnhancer enhancer)
    {
        return new JdoNewInstance2(enhancer, ClassEnhancer.MN_JdoNewInstance, Opcodes.ACC_PUBLIC,
            PersistenceCapable.class, new Class[] {StateManager.class, Object.class}, new String[] {"sm", "obj"});
    }

    /**
     * Constructor.
     * @param enhancer ClassEnhancer
     * @param name Name of method
     * @param access Access type
     * @param returnType Return type
     * @param argTypes Argument types
     * @param argNames Argument names
     */
    public JdoNewInstance2(ClassEnhancer enhancer, String name, int access, 
        Object returnType, Object[] argTypes, String[] argNames)
    {
        super(enhancer, name, access, returnType, argTypes, argNames);
    }

    /**
     * Method to add the contents of the class method.
     */
    public void execute()
    {
        visitor.visitCode();

        Label startLabel = new Label();
        visitor.visitLabel(startLabel);

        if (enhancer.getClassMetaData().isAbstractPersistenceCapable())
        {
            visitor.visitTypeInsn(Opcodes.NEW, "javax/jdo/JDOFatalInternalException");
            visitor.visitInsn(Opcodes.DUP);
            visitor.visitLdcInsn("Cannot instantiate abstract class.");
            visitor.visitMethodInsn(Opcodes.INVOKESPECIAL, "javax/jdo/JDOFatalInternalException",
                "<init>", "(Ljava/lang/String;)V");
            visitor.visitInsn(Opcodes.ATHROW);

            Label endLabel = new Label();
            visitor.visitLabel(endLabel);
            visitor.visitLocalVariable("this", getClassEnhancer().getClassDescriptor(), null, startLabel, endLabel, 0);
            visitor.visitLocalVariable(argNames[0], ASMUtils.CD_StateManager, null, startLabel, endLabel, 1);
            visitor.visitLocalVariable(argNames[1], ASMUtils.CD_Object, null, startLabel, endLabel, 2);
            visitor.visitMaxs(3, 3);
        }
        else
        {
            visitor.visitTypeInsn(Opcodes.NEW, getClassEnhancer().getASMClassName());
            visitor.visitInsn(Opcodes.DUP);
            visitor.visitMethodInsn(Opcodes.INVOKESPECIAL, getClassEnhancer().getASMClassName(), "<init>", "()V");
            visitor.visitVarInsn(Opcodes.ASTORE, 3);
            Label l1 = new Label();
            visitor.visitLabel(l1);
            visitor.visitVarInsn(Opcodes.ALOAD, 3);
            visitor.visitInsn(Opcodes.ICONST_1);
            visitor.visitFieldInsn(Opcodes.PUTFIELD, getClassEnhancer().getASMClassName(), ClassEnhancer.FN_Flag, "B");
            visitor.visitVarInsn(Opcodes.ALOAD, 3);
            visitor.visitVarInsn(Opcodes.ALOAD, 1);
            visitor.visitFieldInsn(Opcodes.PUTFIELD, getClassEnhancer().getASMClassName(), 
                ClassEnhancer.FN_StateManager, ASMUtils.CD_StateManager);
            visitor.visitVarInsn(Opcodes.ALOAD, 3);
            visitor.visitVarInsn(Opcodes.ALOAD, 2);
            visitor.visitMethodInsn(Opcodes.INVOKEVIRTUAL, getClassEnhancer().getASMClassName(), 
                ClassEnhancer.MN_JdoCopyKeyFieldsFromObjectId, "(" + ASMUtils.CD_Object + ")V");
            visitor.visitVarInsn(Opcodes.ALOAD, 3);
            visitor.visitInsn(Opcodes.ARETURN);

            Label endLabel = new Label();
            visitor.visitLabel(endLabel);
            visitor.visitLocalVariable("this", getClassEnhancer().getClassDescriptor(), null, startLabel, endLabel, 0);
            visitor.visitLocalVariable(argNames[0], ASMUtils.CD_StateManager, null, startLabel, endLabel, 1);
            visitor.visitLocalVariable(argNames[1], ASMUtils.CD_Object, null, startLabel, endLabel, 2);
            visitor.visitLocalVariable("result", getClassEnhancer().getClassDescriptor(), null, l1, endLabel, 3);
            visitor.visitMaxs(2, 4);
        }

        visitor.visitEnd();
    }
}