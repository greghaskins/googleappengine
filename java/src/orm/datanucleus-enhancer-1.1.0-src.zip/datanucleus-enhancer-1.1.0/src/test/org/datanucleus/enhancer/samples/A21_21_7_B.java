package org.datanucleus.enhancer.samples;

public class A21_21_7_B extends A21_21_7_A
{
}
