package org.datanucleus.enhancer.samples;

public class A21_21_7_C extends A21_21_7_B
{

}
