package org.datanucleus.enhancer.samples;

public class A21_21_7_A
{
    private A21_21_7_C cclass;

    public A21_21_7_C getCclass()
    {
        return cclass;
    }
}