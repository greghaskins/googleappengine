package org.datanucleus.enhancer.samples;

/**
 * @version $Revision: 1.1 $
 */
public class UserDefinedClass
{
	protected int int1;
	/**
	 * 
	 */
	public UserDefinedClass()
    {
		super();
	}
}
