package org.datanucleus.enhancer.samples;

import java.math.BigDecimal;
import java.math.BigInteger;
import java.util.*;

/**
 * @version $Revision: 1.1 $
 */
public class FullProtectedStaticClass 
{
	protected static boolean field00;
	protected static byte field01;
	protected static short field02;
	protected static char field03;
	protected static int field04;
	protected static float field05;
	protected static long field06;
	protected static double field07;

	protected static Boolean field08;
	protected static Byte field09;
	protected static Short field10;
	protected static Character field11;
	protected static Integer field12;
	protected static Float field13;
	protected static Long field14;
	protected static Double field15;

	protected static String field16;
	protected static Number field17;

	protected static BigDecimal field18;
	protected static BigInteger field19;

	protected static Date field20;
	protected static Locale field21;
	protected static ArrayList field22;
	protected static HashMap field23;
	protected static HashSet field24;
	protected static Hashtable field25;
	protected static LinkedList field26;
	protected static TreeMap field27;
	protected static TreeSet field28;
	protected static Vector field29;
	protected static Collection field30;
	protected static Set field31;
	protected static List field32;
	protected static Map field33;

	protected static FullProtectedStaticClass field34;

	protected static boolean field35[];
	protected static byte field36[];
	protected static short field37[];
	protected static char field38[];
	protected static int field39[];
	protected static float field40[];
	protected static long field41[];
	protected static double field42[];

	protected static Boolean field43[];
	protected static Byte field44[];
	protected static Short field45[];
	protected static Character field46[];
	protected static Integer field47[];
	protected static Float field48[];
	protected static Long field49[];
	protected static Double field50[];

	protected static String field51[];
	protected static Number field52[];

	protected static Date field53[];
	protected static Locale field54[];

	protected static java.io.File n01;
	protected static Void n02;
	protected static UserDefinedClass n03;
	/**
	 * 
	 */
	public FullProtectedStaticClass()
    {
        //default constructor
	}
}
