package org.datanucleus.enhancer.samples;

import java.math.*;
import java.util.*;

/**
 * @version $Revision: 1.1 $
 */
public class FullPublicClass
{
	public boolean field00;
	public byte field01;
	public short field02;
	public char field03;
	public int field04;
	public float field05;
	public long field06;
	public double field07;

	public Boolean field08;
	public Byte field09;
	public Short field10;
	public Character field11;
	public Integer field12;
	public Float field13;
	public Long field14;
	public Double field15;

	public String field16;
	public Number field17;

	public BigDecimal field18;
	public BigInteger field19;

	public Date field20;
	public Locale field21;
	public ArrayList field22;
	public HashMap field23;
	public HashSet field24;
	public Hashtable field25;
	public LinkedList field26;
	public TreeMap field27;
	public TreeSet field28;
	public Vector field29;
	public Collection field30;
	public Set field31;
	public List field32;
	public Map field33;

	public FullPublicClass field34;

	public boolean field35[];
	public byte field36[];
	public short field37[];
	public char field38[];
	public int field39[];
	public float field40[];
	public long field41[];
	public double field42[];

	public Boolean field43[];
	public Byte field44[];
	public Short field45[];
	public Character field46[];
	public Integer field47[];
	public Float field48[];
	public Long field49[];
	public Double field50[];

	public String field51[];
	public Number field52[];

	public Date field53[];
	public Locale field54[];

	public java.io.File n01;
	public Void n02;
	public UserDefinedClass n03;
	/**
	 * 
	 */
	public FullPublicClass()
    {
        //default constructor
	}
}
