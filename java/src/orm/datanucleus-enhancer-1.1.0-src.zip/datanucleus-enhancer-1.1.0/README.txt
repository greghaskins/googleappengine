Enhancer
========
This project provides bytecode enhancement for DataNucleus persistence.

This project is licensed by the Apache 2 license which you should have received with this.
