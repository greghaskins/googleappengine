package javax.persistence;

public enum CacheGetMode 
{
    /** Read entity data from the cache: this is the default behavior. */
    USE,
    /** Bypass the cache: get data directly from the database. */
    BYPASS
}