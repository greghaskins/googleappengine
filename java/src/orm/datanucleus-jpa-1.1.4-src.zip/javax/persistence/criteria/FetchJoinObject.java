package javax.persistence.criteria;

/**
 * Interface used for the result of a fetch join.
 */
public interface FetchJoinObject
{

}