DataNucleus-JPA
===============
This project provides support for JPA persistence.

This project is licensed by the Apache 2 license which you should have received with this.
